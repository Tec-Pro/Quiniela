/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import org.javalite.activejdbc.Model;

/**
 *
 * @author joako
 */
public class Transaccion extends Model {
    
}
