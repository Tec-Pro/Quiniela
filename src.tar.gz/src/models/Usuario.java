/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import org.javalite.activejdbc.Model;
/**
 *
 * @author max
 */
public class Usuario extends Model {
    
}
